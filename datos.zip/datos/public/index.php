<?php
    require "../src/app/app.php";
    